/**
 * Student's Name: Xiangyi (Rosa) Zhu
 * Login: cs11wph
 * Team Name: Ace Team
 *
 * File Name: EventPane.java
 * Description: EventPane.java contain the coding of the visual interface of
 *   some repeated daily events, such as the dialogue boxes and the multiple
 *   choice quiz questions.
 * */
import java.util.*;
import objectdraw.WindowController;
import objectdraw.Location;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.scene.paint.*;
import javafx.event.*;
import java.io.*;
import javafx.beans.property.StringProperty;

/**
 * File Name: EventPane
 * Description: EventPane is a subclass of StackPane, which aims to create the
 *   dialogue boxes, birthday gift selection event, revel quiz event, etc.
 * */
public class EventPane extends StackPane{

  static final Color TRANS_PINK = Color.rgb(255, 192, 203, 0.8);
  static final Color TRANS_BROWN = Color.rgb(130, 65, 20, 0.8);
  static final String BUTTON_STYLE1 =
    "-fx-min-width: 400px; " + "-fx-min-height: 150px; " +
    "-fx-max-width: 400px; " + "-fx-max-height: 200px; " +
    "-fx-background-color: rgb(130, 65, 20, 0.8); " + "-fx-text-fill: pink; " +
    "-fx-font: bold 15px 'garamond'; " + "-fx-alignment: CENTER; ";
  static final String BUTTON_STYLE2 =
    "-fx-min-width: 150px; " + "-fx-min-height: 50px; " +
    "-fx-max-width: 200px; " + "-fx-max-height: 100px; " +
    "-fx-background-color: pink; " + "-fx-text-fill: saddlebrown; " +
    "-fx-font: 14px 'garamond'; " + "-fx-alignment: CENTER; ";
  static final String BUTTON_STYLE3 =
    "-fx-min-width: 300px; " + "-fx-min-height: 50px; " +
    "-fx-max-width: 300px; " + "-fx-max-height: 100px; " +
    "-fx-background-color: rgb(130, 65, 20, 0.8); " + "-fx-text-fill: pink; " +
    "-fx-font: 14px 'garamond'; " + "-fx-alignment: CENTER; ";

  Boolean actionTaken = false;
  Boolean readMessage = false;


  public EventPane() {
    this.setPrefSize(640, 800);
    Button birthdayMessage = new Button("Today is " +
      JavaCat.name + "'s birthday! " +
      "What kind of gift will you buy for her to celebrate her birthday?");
    Button gift1 = new Button("a cozy cat cave");
    Button gift2 = new Button("Revel acces code");
    Button gift3 = new Button("a scratching post");
    Button gift4 = new Button("I am a poor guy...");
   
    birthdayMessage.setStyle(BUTTON_STYLE1);
    birthdayMessage.setWrapText(true);
    gift1.setStyle(BUTTON_STYLE2);
    gift2.setStyle(BUTTON_STYLE2);
    gift3.setStyle(BUTTON_STYLE2);
    gift4.setStyle(BUTTON_STYLE2);

    gift1 = createOption(gift1, "cave");
    gift2 = createOption(gift2, "revel");
    gift3 = createOption(gift3, "scratch");
    gift4 = createOption(gift4, "nothing");

    VBox giftBox = new VBox (30, gift1, gift2, gift3, gift4);
    giftBox.setAlignment(Pos.CENTER);
    VBox birthdayBox = new VBox (60, birthdayMessage, giftBox);
    birthdayBox.setAlignment(Pos.CENTER);
    this.getChildren().add(birthdayBox);
  }

  // quiz event with three options
  public EventPane (String question, String option1, String answer1,
  String option2, String answer2, String option3) {
    actionTaken = false;
    this.setPrefSize(640, 800);
    Button btnQuestion = new Button(question);
    Button btn1 = new Button(option1);
    Button btn2 = new Button(option2);
    Button btn3 = new Button(option3);
    btnQuestion.setStyle(BUTTON_STYLE1);
    btnQuestion.setWrapText(true);
    btn1.setStyle(BUTTON_STYLE2);
    btn2.setStyle(BUTTON_STYLE2);
    btn3.setStyle(BUTTON_STYLE2);

    btn1 = createOption(btn1, answer1);
    btn2 = createOption(btn2, answer2);
    btn3 = createOption(btn3, "bad attitude");

    VBox optionBox = new VBox (30, btn1, btn2, btn3);
    optionBox.setAlignment(Pos.CENTER);
    VBox eventBox = new VBox (60, btnQuestion, optionBox);
    eventBox.setAlignment(Pos.CENTER);
    this.getChildren().add(eventBox);
  }

  public EventPane (String s) {
    readMessage = false;
    this.setPrefSize(640, 800);
    Button text = new Button(s);
    text.setStyle(BUTTON_STYLE3);
    text.setWrapText(true);
    text = createOption(text, "next");
    this.getChildren().add(text);
  }

  public EventPane (String[] arrs) {
    readMessage = false;
    this.setPrefSize(640, 800);
    Button text = new Button(arrs[0]);
    text.setStyle(BUTTON_STYLE3);
    text.setWrapText(true);
    this.createOption(text, arrs);
    this.getChildren().add(text);
  }

  public void clearPane() {
    // remove this EventPane from its parent, backgroundPane, in JavaCat.java
    ((Pane)this.getParent()).getChildren().remove(this);
  }

  public Button createOption(Button btn, String judge) {
    if (judge.equals("correct")) {
      btn.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          for (int i = 0; i < 5; i++) {
            JavaCat.intelligence = JavaCat.increment(JavaCat.intelligence);
          }
          JavaCat.intimacy = JavaCat.increment(JavaCat.intimacy);
          JavaCat.upDateVariables();
          JavaCat.upDateIntimacy();
          actionTaken = true;
          JavaCat.backgroundPane.getChildren().add
          (new EventPane(JavaCat.name + ": True!!"));
          try {
            JavaCat.backgroundPane.getChildren().remove(EventCollection.revel);
          }
          catch (NullPointerException e1) {
          }
          clearPane();
        }
      });
    }
    else if (judge.equals("wrong")) {
      btn.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          JavaCat.intelligence = JavaCat.decrement(JavaCat.intelligence);
          JavaCat.intimacy = JavaCat.decrement(JavaCat.intimacy);
          JavaCat.upDateVariables();
          JavaCat.upDateIntimacy();
          actionTaken = true;
          JavaCat.backgroundPane.getChildren().add(new EventPane(JavaCat.name +
          ": False..."));
          try {
            JavaCat.backgroundPane.getChildren().remove(EventCollection.revel);
          }
          catch (NullPointerException e1) {
          }
          clearPane();
        }
      });
    }
    else if (judge.equals("bad attitude")) {
      btn.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          JavaCat.rebellion = JavaCat.increment(JavaCat.rebellion);
          JavaCat.intimacy = JavaCat.decrement(JavaCat.intimacy);
          JavaCat.upDateVariables();
          JavaCat.upDateIntimacy();
          actionTaken = true;
          JavaCat.backgroundPane.getChildren().add(new EventPane(JavaCat.name +
          ": System.out.print(F**k)"));
          try {
            JavaCat.backgroundPane.getChildren().remove(EventCollection.revel);
          }
          catch (NullPointerException e1) {
          }
          clearPane();
        }
      });
    }
    else if (judge.equals("next")) {
      btn.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          clearPane();
        }
      });
    }
    else if (judge.equals("cave")) {
      btn.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          for (int i = 0; i < 20; i++) {
            JavaCat.intimacy = JavaCat.increment(JavaCat.intimacy);
          }
          JavaCat.upDateVariables();
          JavaCat.upDateIntimacy();
          JavaCat.backgroundPane.getChildren().add(new EventPane(JavaCat.name +
          " looks very happy!"));
          clearPane();
        }
      });
    }
    else if (judge.equals("revel")) {
      btn.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          for (int i = 0; i < 20; i++) {
            JavaCat.intelligence = JavaCat.increment(JavaCat.intelligence);
          }
          JavaCat.upDateVariables();
          JavaCat.upDateIntimacy();
          JavaCat.backgroundPane.getChildren().add(new EventPane(JavaCat.name +
          " becomes smarter!"));
          clearPane();
        }
      });
    }
    else if (judge.equals("scratch")) {
      btn.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          for (int i = 0; i < 20; i++) {
            JavaCat.rebellion = JavaCat.decrement(JavaCat.rebellion);
          }
          JavaCat.upDateVariables();
          JavaCat.upDateIntimacy();
          JavaCat.backgroundPane.getChildren().add(new EventPane(JavaCat.name +
          " becomes more gentle!"));
          clearPane();
        }
      });
    }
    else if (judge.equals("nothing")) {
      btn.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          for (int i = 0; i < 10; i++) {
            JavaCat.intimacy = JavaCat.decrement(JavaCat.intimacy);
            JavaCat.rebellion = JavaCat.increment(JavaCat.rebellion);
          }
          JavaCat.upDateVariables();
          JavaCat.upDateIntimacy();
          String[] angry = new String[] {
            JavaCat.name + ": F**k!",
            JavaCat.name + ": for (int i = 0; i < 100; i++) {",
            JavaCat.name + ": System.out.println(F**k!)",
            "You: Well... nice coding, " + JavaCat.name + " :)",
            "You: But don't forget to add the semicolon and curly brace!"};
          JavaCat.backgroundPane.getChildren().add(new EventPane(angry));
          clearPane();
        }
      });
    }
    return btn;
  }

  public Button createOption(Button btn, String[] array) {
    btn.setOnAction(new EventHandler<ActionEvent>() {
      public void handle(ActionEvent event) {
        clearPane();
        String[] arr;
        // use exception handler to deal with the runtime exception error.
        try {
          // use recursion to display the dialogue boxes in the game
          arr = Arrays.copyOfRange(array, 1, array.length);
          JavaCat.backgroundPane.getChildren().add(new EventPane(arr));
        }
        catch (ArrayIndexOutOfBoundsException e2) {
          readMessage = true;
          if (EventCollection.end) {
            System.exit(0);
          }
          try {
            JavaCat.backgroundPane.getChildren().remove(EventCollection.revel);
          }
          catch (NullPointerException e1) {
          }
        }
      }
    });
    return btn;
  }

}
