/**
 * Student's Name: Xiangyi (Rosa) Zhu
 * Login: cs11wph
 * Team Name: Ace Team
 *
 * File Name: JavaCat.java
 * Description: This file contains the coding of the game JavaCat, which
 *   provides a relaxing way the learn and review CSE11.
 * */
import java.util.*;
import objectdraw.WindowController;
import objectdraw.Location;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.scene.paint.*;
import javafx.event.*;
import java.io.*;

/**
 * Class Name: JavaCat
 * Description: The JavaCat class aims to create a visual user interface using
 *   javaFx. The variables of our cat, such as the foodLevel and intimacy, can
 *   be changed by each kind of the interactions.
 * */
public class JavaCat extends Application {

  // declare and initialize static variables such as foodLevel, intimacy,
  // intelligence, and rebellion.
  static int foodLevel = 50;
  static int intimacy = 25;
  static int intelligence = 0;
  static int rebellion = 25;

  static String name = "cat";
  static String dateOfBirth = "1";
  static String monthOfBirth = "January";
  static boolean awake = true;
  private static int patCount = 0;
  Random random = new Random();

  static int count = 0;
  static int time;
  static int date;
  static int month;
  
  // declare and initialize some frequently used constants.
  private static final int TWO = 2;
  private static final int THREE = 3;
  private static final int FIVE = 5;
  private static final int TEN = 10;
  private static final int TWENTY_FIVE = 25;
  private static final int TWENTY_EIGHT = 28;
  private static final int FIFTY = 50;
  private static final int SEVENTY_FIVE = 75;
  private static final int HUNDRED = 100;
  private static final Color TRANS_PINK = Color.rgb(255, 192, 203, 0.8);
  private static final Color TRANS_BROWN = Color.rgb(130, 65, 20, 0.8);
  private static final String BUTTON_STYLE = "-fx-background-radius: 50px; " +
    "-fx-min-width: 90px; " + "-fx-min-height: 100px; " +
    "-fx-max-width: 90px; " + "-fx-max-height: 100px; " +
    "-fx-background-color: saddlebrown; " + "-fx-text-fill: pink; " +
    "-fx-font: bold 15px 'garamond' ";

  // declare and construct some elements within GUI interface
  static Pane backgroundPane;
  static BorderPane pane;
  private static Text txName = new Text("Name: " + name);
  private static Text txFoodLevel = new Text("Food Level: " + getFoodLevel());
  private static Text txIntelligence =
    new Text("Intelligence: " + intelligence);
  private static Text txRebellion = new Text("Rebellion: " + rebellion);
  private static Rectangle variableRec = new Rectangle(0, 0, 150, 175);
  private static Line line = new Line(0, 0, 120, 0);
  private static VBox variableBox = new VBox(20);
  private static Pane leftPane;

  private static Text txMonthAndDate =
    new Text(calculateMonth() + calculateDate());
  private static Text txTime = new Text(calculateTime());
  private static VBox timeBox = new VBox(20);

  private static Button feed = new Button("feed");
  private static Button pat = new Button("pat");
  private static Button scold = new Button("scold");
  private static Button skip = new Button("skip");
  private static Button start = new Button("-play-");

  private static Text txIntimacy = new Text(155, 13, intimacy + " / 100");
  private static double intimacyWidth = (intimacy / 100.0 ) * 360.0;
  private static Rectangle intimacyRec = new Rectangle(0, 0, intimacyWidth, 18);
  private static Rectangle intimacyFrame = new Rectangle(-1, -1, 362, 20);
  private static Pane bottomPane = new Pane();
  private static HBox intimacyBox = new HBox();
  static StackPane startPane = new StackPane();
  private static TextField inputName = new TextField();
  private static ChoiceBox<String> inputMonth = new ChoiceBox<>();
  private static ChoiceBox<String> inputDate = new ChoiceBox<>();
  private static ImageView heart = new ImageView("image/heart.gif");
  static ImageView background = new ImageView("image/morning_1.gif");
  static ImageView inroBackground = new ImageView("image/intro.gif");
  static ImageView cat = new ImageView("image/cat_normal1.gif");

  /**
   * The start method constructs and displays the stage on canvas, which
   * overrides the start method in Application class.
   * The start method hasn't been finished and finalized yet.
   * @param Stage primaryStage: The stage in which we construct the scene, and
   *        it is displayed on canvas.
   */ 
  @Override
  public void start(Stage primaryStage) {
    // create a pane to hold the texts and images.
    pane = new BorderPane();
    pane.setPrefWidth(640);
    pane.setPrefHeight(800);

    txName.setFill(Color.SADDLEBROWN);
    txFoodLevel.setFill(Color.SADDLEBROWN);
    txIntelligence.setFill(Color.RED);
    txRebellion.setFill(Color.SADDLEBROWN);
    line.setStroke(Color.SADDLEBROWN);
    line.getStrokeDashArray().addAll(8.0);
    variableBox.getChildren().addAll
      (txName, line, txFoodLevel, txIntelligence, txRebellion);

    leftPane = new StackPane();
    variableRec.setFill(TRANS_PINK);
    variableRec.setArcWidth(20);
    variableRec.setArcHeight(20);
    leftPane.getChildren().addAll(variableRec, variableBox);
    pane.setLeft(leftPane);
    pane.setMargin(leftPane, new Insets(100,0,0,40));
    variableBox.setAlignment(Pos.CENTER);

    timeBox.setPadding(new Insets(0, 50, 580, 0));
    txMonthAndDate.setFill(Color.SADDLEBROWN);
    txMonthAndDate.setFont(Font.font("Garamond", FontWeight.BOLD, 15));
    txTime.setFill(Color.SADDLEBROWN);
    txTime.setFont(Font.font("Garamond", 12));
    timeBox.getChildren().addAll(txMonthAndDate, txTime);
    pane.setRight(timeBox);
    timeBox.setAlignment(Pos.CENTER);

    intimacyRec.setArcWidth(6);
    intimacyRec.setArcHeight(6);
    intimacyRec.setFill(Color.SADDLEBROWN);
    intimacyFrame.setFill(new Color(0, 0, 0, 0));
    intimacyFrame.setStroke(Color.PINK);
    intimacyFrame.setArcWidth(6);
    intimacyFrame.setArcHeight(6);
    intimacyBox.getChildren().add(intimacyRec);
    intimacyBox.setAlignment(Pos.BOTTOM_LEFT);
    txIntimacy.setFill(Color.PINK);
    txIntimacy.setFont(Font.font("Garamond", FontWeight.BOLD, 12));
    heart.setFitHeight(50);
    heart.setFitWidth(45);
    heart.setX(-36);
    heart.setY(-18);

    bottomPane.getChildren().addAll
      (intimacyFrame, intimacyBox, heart, txIntimacy);
    pane.setBottom(bottomPane);
    pane.setMargin(bottomPane, new Insets(0,0,20,150));

    Pane centerPane = new Pane();
    feed.setStyle(BUTTON_STYLE);
    feed.setLayoutX(-130);
    feed.setLayoutY(150);
    feed.setRotate(-25);

    pat.setStyle(BUTTON_STYLE);
    pat.setLayoutX(-10);
    pat.setLayoutY(50);

    scold.setStyle(BUTTON_STYLE);
    scold.setLayoutX(170);
    scold.setLayoutY(50);

    skip.setStyle(BUTTON_STYLE);
    skip.setRotate(25);
    skip.setLayoutX(290);
    skip.setLayoutY(150);

    centerPane.getChildren().addAll
      (createButton("feed"), createButton("pat"), createButton("scold"), createButton("skip"));
    pane.setCenter(centerPane);

    background.setFitHeight(800);
    background.setFitWidth(640);
    background.setX(0);
    background.setY(0);
    backgroundPane = new Pane();
    backgroundPane.getChildren().addAll(background, pane);

    Rectangle startRec = new Rectangle(400, 400);
    startRec.setFill(TRANS_BROWN);
    startRec.setArcWidth(50);
    startRec.setArcHeight(50);

    VBox startBox = new VBox(65);
    Text txTitle = new Text("Welcome to JavaCat");
    txTitle.setFill(Color.PINK);
    txTitle.setFont(Font.font("Garamond", FontWeight.BOLD, 20));

    Text txInputName = new Text("Name:");
    txInputName.setFill(Color.PINK);
    txInputName.setFont(Font.font("Garamond", 15));

    inputName.setPromptText("Enter the name of your cat.");
    inputName.setPrefColumnCount(15);

    HBox nameBox = new HBox(25, txInputName, inputName);
    
    Text txInputBirthday = new Text("Birthday:");
    txInputBirthday.setFill(Color.PINK);
    txInputBirthday.setFont(Font.font("Garamond", 15));

    inputMonth.getItems().addAll("January", "February", "March");
    inputDate.getItems().addAll(
      "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
      "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
      "21", "22", "23", "24", "25", "26", "27", "28");

    HBox birthdayBox = new HBox(25, txInputBirthday, inputMonth, inputDate);

    startBox.getChildren().addAll(txTitle, nameBox, birthdayBox, createButton("start"));
    nameBox.setAlignment(Pos.CENTER);
    birthdayBox.setAlignment(Pos.CENTER);
    startBox.setAlignment(Pos.CENTER);
    startPane.setAlignment(Pos.CENTER);
    startPane.setPrefSize(640, 800);
    startPane.getChildren().addAll(startRec, startBox);

    backgroundPane.getChildren().addAll(inroBackground, startPane);

    // create a scene that is 640 px wide and 800 px high.
    Scene scene = new Scene(backgroundPane, 640, 800);
    primaryStage.setTitle("Java Cat");		// set the stage title
    primaryStage.setScene(scene);		// place the scene in the stage
    primaryStage.show();			// display the stage
    primaryStage.setResizable(false);
  }
  
  public static void main(String[] args) {
    launch(args);
    // The game would terminate three months after the cat was adopted.
    if (count == THREE * THREE * TWENTY_EIGHT - 1) {
      System.out.println("-Game Over-");
    }
  }

  public Button createButton(String s) {
    if (s.equals("feed")) {
      feed.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          count++;
          foodLevel += 30;
          patCount = decrement(patCount);
          patCount = decrement(patCount);
          // The rebellion level increases by one every morning
          if (count % 3 == 0) {
            rebellion = increment(rebellion);
          }
          upDateVariables();
          upDateTime();
          EventCollection.events();
        }
      });
      return feed;
    }
    if (s.equals("pat")) {
      pat.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          pat();
          upDateVariables();
          upDateIntimacy();
          upDateTime();
          EventCollection.events();
        }
      });
      return pat;
    }
    if (s.equals("scold")) {
      scold.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          scold();
          upDateVariables();
          upDateIntimacy();
          upDateTime();
          EventCollection.events();
        }
      });
      return scold;
    }
    if (s.equals("skip")) {
      skip.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          foodLevel -= 5;
          count++;
          patCount = decrement(patCount);
          patCount = decrement(patCount);
          if (count % 3 == 0) {
            rebellion = increment(rebellion);
          }
          upDateVariables();
          upDateIntimacy();
          upDateTime();
          EventCollection.events();
        }
      });
      return skip;
    }
    else {
      Text warning1 = new Text(275, 390, "Please enter a valid name.");
      warning1.setFill(Color.PINK);
      warning1.setFont(Font.font("Garamond", 12));
      Text warning2 = new Text(285, 390, "Shorter name please!");
      warning2.setFill(Color.PINK);
      warning2.setFont(Font.font("Garamond", 12));
      Text warning3 = new Text(255, 480, "Please select the birthday of your cat.");
      warning3.setFill(Color.PINK);
      warning3.setFont(Font.font("Garamond", 12));

      start.setOnAction(new EventHandler<ActionEvent>() {
        public void handle(ActionEvent event) {
          if (inputName.getText().trim().equals("")) {
            backgroundPane.getChildren().removeAll(warning1, warning2, warning3);
            backgroundPane.getChildren().add(warning1);
            if (inputDate.getValue() == null || inputMonth.getValue() == null) {
              backgroundPane.getChildren().add(warning3);
            }
          }

          else if (inputName.getText().length() > 12) {
            backgroundPane.getChildren().removeAll(warning1, warning2, warning3);
            backgroundPane.getChildren().add(warning2);
            if (inputDate.getValue() == null || inputMonth.getValue() == null) {
              backgroundPane.getChildren().add(warning3);
            }
          }
          else {
            backgroundPane.getChildren().removeAll(warning1, warning2, warning3);
            if (inputDate.getValue() == null || inputMonth.getValue() == null) {
              backgroundPane.getChildren().add(warning3);
            }
            else {
              name = inputName.getText();
              monthOfBirth = inputMonth.getValue();
              dateOfBirth = inputDate.getValue();
              backgroundPane.getChildren().clear();

              String[] introMessage = new String[]
                {"Congratulation! You adopt a super smart cat from a local " +
                 "animal shelter!",
                 "Her name is " + name + "."};
              EventPane introduction1 = new EventPane(introMessage);
              cat.setFitWidth(300);
              cat.setFitHeight(200);
              cat.setX(160);
              cat.setY(470);
              backgroundPane.getChildren().addAll
              (background, cat, pane, introduction1);
              upDateVariables();
            }
          }
        }
      });
      return start;
    }
  }

  /**
   * Class Title: JavaCatInteraction
   * Description: JavaCatInteraction is a inner class within JavaCat, which
   *   extends WindowController. This class allows the program to determine
   *   which interaction option is selected by the player using onMouseClick
   *   method.
   * */ 
  public class JavaCatInteraction extends WindowController {
    public void onMouseClick(Location point) {
    }
  }

  /**
   * The pat() method method will make the intimacy increase if the patcount 
   * less than or equal to 3, and decrease the intimacy if the patcount number
   * greater than 5.
   */
  public static void pat() {
    // if the patcount number greater than 5, each pat will decrease the
    // intimacy one.
    if (patCount > FIVE) {
      intimacy = decrement(intimacy);
    }
    // if the patcount number less than or equal to 5 and greater than 3, 
    // each pat will not change the intimacy.
    else if (patCount > THREE) {
      patCount++;
    }
    // if the patcount number less than or equal to 3, each pat will 
    // make the intimacy increase by one.
    else {
      patCount++;
      intimacy = increment(intimacy);
    }
    // After each interaction foodlevel decreases by 5 and count increases by 1
    foodLevel -= FIVE;
    count++;
    if (count % 3 == 0) {
      rebellion = increment(rebellion);
    }
  }

  /** 
   * Rebuke method will make the intimacy decrease by two if the rebellion
   * greater than 75. It will make the intimacy decrease by one if the 
   * rebellion less than or equal to 75.
   */
  public static void scold() {
    // if the rebellion greater than 75, each rebellion will make the intimacy
    // decrease by 5.
    if (rebellion > SEVENTY_FIVE) {
      for (int i = 0; i < 5; i++) {
        intimacy = decrement(intimacy);
      }
    }
    // If the rebellion less than or equal to 75, each time we rebuke the cat,
    // rebellion and intimacy level would both be decreased by 2.
    else {
      intimacy = decrement(intimacy);
      intimacy = decrement(intimacy);
    }
    rebellion = decrement(rebellion);
    rebellion = decrement(rebellion);
    foodLevel -= FIVE;
    patCount = decrement(patCount);
    patCount = decrement(patCount);
    count++;
    if (count % 3 == 0) {
      rebellion = increment(rebellion);
    }
  }

  // calculateTime method is used to calculate the time within a day.
  public static String calculateTime() {
    time = count % THREE;
    if (time == 0) {
      return "Morning";
    }
    if (time == 1) {
      return "Afternoon";
    }
    else {
      return "Evening";
    }
  }

  // calculateDate method is used to calculate the date within a month.
  public static String calculateDate() {
    date = (count / THREE) % TWENTY_EIGHT + 1;
    if (date == 1 || date == 21) {
      return " " + date + "st";
    }
    else if (date == 2 || date == 22) {
      return " " + date + "nd";
    }
    else if (date == 3 || date == 23) {
      return " " + date + "rd";
    }
    else {
      return " " + date + "th";
    }
  }

  // calculateMonth method is used to calculate the month in the game.
  public static String calculateMonth() {
    month = (count / THREE) / TWENTY_EIGHT + 1;
    if (month == 1) {
      return "January";
    }
    if (month == TWO) {
      return "February";
    }
    else {
      return "March";
    }
  }

  /**
   * foodLevelPlus method: this metnod is used to return the foodlevel 
   * of the cat
   *
   */

  public static int getFoodLevel() {
    if (foodLevel < HUNDRED) {
      return foodLevel;
    }
    else {
      return HUNDRED;
    }
  }

  /**
   * increment method: this method is used to count the variable
   * if the variable less than 100, each increament will make 
   * the variable increase 1, and the variable can't greater than 100
   */
  public static int increment(int variable) {
    if (variable < HUNDRED) {
      variable++;
      return variable;
    }
    else {
      return HUNDRED;
    }
  }

  /**
   * decreament method is used to count the variable if the variable greater
   * than 0, each decrement will make variable decrease 1.
   * In addition, those static variables such as intimacy can't less than 0.
   */
  public static int decrement(int variable) {
    if (variable > 0) {
      variable--;
      return variable;
    }
    else {
      return 0;
    }
  }

  public static void upDateVariables() {
    variableBox.getChildren().clear();
    leftPane.getChildren().remove(variableBox);
    txName = new Text("Name: " + name);
    txFoodLevel = new Text("Food Level: " + getFoodLevel());
    txIntelligence = new Text("Intelligence: " + intelligence);
    txRebellion = new Text("Rebellion: " + rebellion);
    txName.setFill(Color.SADDLEBROWN);
    txFoodLevel.setFill(Color.SADDLEBROWN);
    txIntelligence.setFill(Color.SADDLEBROWN);
    txRebellion.setFill(Color.SADDLEBROWN);
    if (foodLevel < 25 || foodLevel >= 100) {
      txFoodLevel.setFill(Color.RED);
    }
    if (intelligence < 25) {
      txIntelligence.setFill(Color.RED);
    }
    if (rebellion > 75) {
      txRebellion.setFill(Color.RED);
    }
    variableBox.getChildren().addAll
      (txName, line, txFoodLevel, txIntelligence, txRebellion);
    leftPane.getChildren().add(variableBox);
    variableBox.setAlignment(Pos.CENTER);
    pane.setLeft(leftPane);
  }

  public static void upDateIntimacy() {
    intimacyBox.getChildren().clear();
    bottomPane.getChildren().remove(intimacyBox);
    intimacyWidth = (intimacy / 100.0 ) * 360.0;
    intimacyRec = new Rectangle(0, 0, intimacyWidth, 18);
    intimacyRec.setArcWidth(6);
    intimacyRec.setArcHeight(6);
    intimacyRec.setFill(Color.SADDLEBROWN);
    intimacyBox.getChildren().add(intimacyRec);
    intimacyBox.setAlignment(Pos.BOTTOM_LEFT);
    bottomPane.getChildren().add(intimacyBox);
    bottomPane.getChildren().removeAll(heart, txIntimacy);
    txIntimacy = new Text(155, 13, intimacy + " / 100");
    txIntimacy.setFont(Font.font("Garamond", FontWeight.BOLD, 12));
    txIntimacy.setFill(Color.PINK);
    bottomPane.getChildren().addAll(heart, txIntimacy);
    pane.setBottom(bottomPane);
  }

  public static void upDateTime() {
    timeBox.getChildren().clear();
    backgroundPane.getChildren().clear();

    txMonthAndDate = new Text(calculateMonth() + calculateDate());
    txTime = new Text(calculateTime());
    txMonthAndDate.setFill(Color.SADDLEBROWN);
    txMonthAndDate.setFont(Font.font("Garamond", FontWeight.BOLD, 15));
    txTime.setFill(Color.SADDLEBROWN);
    txTime.setFont(Font.font("Garamond", 12));
    timeBox.getChildren().addAll(txMonthAndDate, txTime);
    pane.setRight(timeBox);
    timeBox.setAlignment(Pos.CENTER);

    switch (count % 9) {
      case 1:
        background = new ImageView("image/afternoon_1.gif");
        cat = new ImageView("image/cat_normal1.gif");
        cat.setFitWidth(300);
        cat.setFitHeight(200);
        cat.setX(160);
        cat.setY(470);
        break;
      case 2:
        background = new ImageView("image/night_1.gif");
        cat = new ImageView("image/cat_normal2.gif");
        cat.setFitWidth(380);
        cat.setFitHeight(380);
        cat.setX(130);
        cat.setY(340);
        break;
      case 3:
        background = new ImageView("image/morning_2.gif");
        cat = new ImageView("image/cat_sleep.gif");
        cat.setFitWidth(300);
        cat.setFitHeight(250);
        cat.setX(175);
        cat.setY(430);
        break;
      case 4:
        background = new ImageView("image/afternoon_2.gif");
        cat = new ImageView("image/cat_normal1.gif");
        cat.setFitWidth(300);
        cat.setFitHeight(200);
        cat.setX(160);
        cat.setY(470);
        break;
      case 5:
        background = new ImageView("image/night_2.gif");
        cat = new ImageView("image/cat_normal3.gif");
        cat.setFitWidth(300);
        cat.setFitHeight(300);
        cat.setX(170);
        cat.setY(385);
        break;
      case 6:
        background = new ImageView("image/morning_3.gif");
        cat = new ImageView("image/cat_normal1.gif");
        cat.setFitWidth(300);
        cat.setFitHeight(200);
        cat.setX(160);
        cat.setY(465);
        break;
      case 7:
        background = new ImageView("image/afternoon_3.gif");
        cat = new ImageView("image/cat_sleep.gif");
        cat.setFitWidth(300);
        cat.setFitHeight(250);
        cat.setX(175);
        cat.setY(430);
        break;
      case 8:
        background = new ImageView("image/night_3.gif");
        cat = new ImageView("image/cat_normal5.gif");
        cat.setFitWidth(440);
        cat.setFitHeight(440);
        cat.setX(100);
        cat.setY(220);
        break;
      default:
        background = new ImageView("image/morning_1.gif");
        cat = new ImageView("image/cat_normal1.gif");
        cat.setFitWidth(300);
        cat.setFitHeight(200);
        cat.setX(160);
        cat.setY(470);
    }
    background.setX(0);
    background.setY(0);

    backgroundPane.getChildren().addAll(background, cat, pane);
  }
}

