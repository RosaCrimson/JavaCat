import java.util.*;
import objectdraw.WindowController;
import objectdraw.Location;
import javafx.application.Application;
import javafx.geometry.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.scene.paint.*;
import javafx.event.*;
import java.io.*;

public class EventCollection {

  private static Random generator = new Random();
  static ImageView revel = new ImageView("image/revel.jpg");
  private static int index = 0;
  static boolean end = false;

  static EventPane quiz1 = new EventPane
    ("Which of the following are correct ways to declare variables?",
    "A. int length; int width;", "correct", "B. int length, width;", "wrong",
    "C. Who cares?");
  static EventPane quiz2 = new EventPane
    ("What is the representation of the third element in an array called a?",
    "A. =<", "wrong", "B. <=", "correct", "C. Stop asking!");
  static EventPane quiz3 = new EventPane
    ("The less than or equal to comparison operator in Java is:",
    "A. a(3)", "wrong", "B. a[2]", "correct", "C. What??");
  static EventPane quiz4 = new EventPane
    ("How many elements are in array double[] list = new double[5]?",
    "A. 5", "correct", "B. 6", "wrong", "C. No idea!!");
  static EventPane quiz5 = new EventPane
    ("When you pass an array to a method, the method receives _____.",
    "A. the reference of the array", "correct", "B. a copy of the array",
    "wrong", "C. a copy of JavaCat!!");
  static EventPane quiz6 = new EventPane
    ("The JVM stores the array in an area of memory, called _____, which " +
    "is used for dynamic memory allocation where blocks of memory are " +
    "allocated and freed in an arbitrary order.",
    "A. stack", "wrong", "B. heap", "correct", "C. in your mind!!");
  static EventPane quiz7 = new EventPane
    ("_____ is invoked to create an object.",
    "A. A constructor", "correct", "B. A method with a return type",
    "wrong", "C. I am the GOD!");
  static EventPane quiz8 = new EventPane
    ("The default value for data field of a boolean type, numeric type, " +
    "object type is _____, respectively.",
    "A. false, 0, null", "correct", "B. true, 1, Null", "wrong", 
    "C. cat, kitty, kitten");
  static EventPane quiz9 = new EventPane
    ("A method that is associated with an individual object is called _____.",
    "A. a static method", "wrong", "B. an instance method", "correct", 
    "C. I don't care...");
  static EventPane quiz10 = new EventPane
    ("You can declare two variables with the same name in _____.",
    "A. two nested blocks in a method", "wrong",
    "B. different methods in a class", "correct", "C. in your heart~");

  static EventPane[] quizArray = new EventPane[] {quiz1, quiz2, quiz3, quiz4,
  quiz5, quiz6, quiz7, quiz8, quiz9, quiz10};

  public static void events() {
    if (JavaCat.count == 3 * 3 * 28 - 1) {
      end = true;
      String[] endText =
        new String[] {"Three months has passed since you first met " +
        JavaCat.name + ", and obviouly you two have learned a lot.",
        "Due to the limited time, I am not able to create multiple endings",
        "But I hope at least you enjoy this game...",
        "-The End-"};
      JavaCat.backgroundPane.getChildren().add(new EventPane(endText));
 
    }
    // If the foodLevel reaches 0 or below, the cat would die.
    else if (JavaCat.foodLevel <= 0) {
      end = true;
      String[] deathText1 =
        new String[] {"You forget to feed " + JavaCat.name + " for days...",
        "The poor little thing starves to death...",
        "-Game Over-"};
      JavaCat.backgroundPane.getChildren().add(new EventPane(deathText1));
    }
    else if (JavaCat.foodLevel >= 300) {
      end = true;
      String[] deathText2 =
        new String[] {"You definitely spoil " + JavaCat.name +
        " with your love.",
        "You overfeed her because you care so much about her.",
        "But last night she aet too much, and she died peacefully..",
        "-Game Over-"};
      JavaCat.backgroundPane.getChildren().add(new EventPane(deathText2));
    }
    else if ((JavaCat.date + "").equals(JavaCat.dateOfBirth) &&
    JavaCat.calculateMonth().equals(JavaCat.monthOfBirth) &&
    JavaCat.count % 3 == 0){
      JavaCat.backgroundPane.getChildren().add(new EventPane());
    }
    else if (JavaCat.date == 3 && JavaCat.month == 1 &&
    JavaCat.count % 3 == 2) {
      JavaCat.backgroundPane.getChildren().add(revel);
      revel.setX(100);
      revel.setY(70);
      String[] quizText1 = new String[] {"You are taking CSE11 this quarter.",
      JavaCat.name +
      " seems to be really interested in your CSE11 textbook - Revel Java.",
      "She moves her paw to a Revel quiz queation!!",
      "Maybe we can study CSE11 together..."};
      EventPane quizPane1 = new EventPane(quizText1);
      JavaCat.backgroundPane.getChildren().add(quizPane1);
    }
    else if (JavaCat.date % 3 == 0 && JavaCat.count % 3 == 2) {
      JavaCat.backgroundPane.getChildren().add(revel);
      revel.setX(100);
      revel.setY(70);
      quiz();
    }
  }

  public static void quiz() {
    index = generator.nextInt(quizArray.length);
    JavaCat.backgroundPane.getChildren().add(quizArray[index]);
  }
}
